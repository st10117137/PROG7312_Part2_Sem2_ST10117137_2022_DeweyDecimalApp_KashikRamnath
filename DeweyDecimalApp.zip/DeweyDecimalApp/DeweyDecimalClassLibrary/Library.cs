﻿namespace DeweyDecimalClassLibrary
{
    public class Library
    {
        public List<string> callNumber = new List<string>();
        public List<string> description = new List<string>();
        public List<string> answers = new List<string>();

        public Library()
        {
            callNumber.Add("000");
            callNumber.Add("100");
            callNumber.Add("200");
            callNumber.Add("300");
            callNumber.Add("400");
            callNumber.Add("500");
            callNumber.Add("600");
            callNumber.Add("700");
            callNumber.Add("800");
            callNumber.Add("900");

            description.Add("General Knowlege");
            description.Add("Philosophy and Psychology");
            description.Add("Religion");
            description.Add("Social Sciences");
            description.Add("Languages");
            description.Add("Science");
            description.Add("Technology");
            description.Add("Arts and Culture");
            description.Add("Literature");
            description.Add("History and Geography");

            answers.Add("000 General Knowlege");
            answers.Add("100 Philosophy and Psychology");
            answers.Add("200 Religion");
            answers.Add("300 Social Sciences");
            answers.Add("400 Languages");
            answers.Add("500 Science");
            answers.Add("600 Technology");
            answers.Add("700 Arts and Culture");
            answers.Add("800 Literature");
            answers.Add("900 History and Geography");

        }

    }
}