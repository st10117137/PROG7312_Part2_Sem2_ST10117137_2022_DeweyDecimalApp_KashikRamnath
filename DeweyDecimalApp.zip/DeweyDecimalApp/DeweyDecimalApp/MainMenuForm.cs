namespace DeweyDecimalApp
{
    public partial class MainMenuForm : Form
    {
        public MainMenuForm()
        {
            InitializeComponent();

            this.ControlBox = false;

        }

        private void btn_replacingBooks_Click(object sender, EventArgs e)
        {
            this.Hide();
            replacingBooksForm rbf = new replacingBooksForm(); //this is the change, code for redirect  
            rbf.ShowDialog();
        }

        private void btn_identifyingAreas_Click(object sender, EventArgs e)
        {
            this.Hide();
            identifyingAreasForm rbf = new identifyingAreasForm(); //this is the change, code for redirect  
            rbf.ShowDialog();
        }

        private void btn_findingCallNumbers_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This feature will be implemented in the next version", 
                "Coming Soon", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}